#!/local/bin/perl

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =
    localtime(time);

$progdir = `pwd`;
$progdir =~ /[^\/]+$/ || die("oops!");
$progdir = $&; $progdir =~ s/\s*$//;

$tid = sprintf("$progdir-%04.0f-%02.0f-%02.0f_%02.0f-%02.0f.zip", $year+1900, $mon+1, $mday, $hour, $min);

# chdir("/mnt/dosd/usit/prissmon");
$targetfile = "/mnt/auto/sauron_u1_runefro/usit/NT/$tid";
system("zip -rp $targetfile *.c* *.h* *.pl *.d* *.rc *.mak *.inf *.mdp */*.exe */*.dll");
print "Zip file in $targetfile\n";

